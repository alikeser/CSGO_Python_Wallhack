# csgo-cheat

Compact external cheat written in python. It is not detected by Vac but it should only be run in insecure mode against bots for educational purposes only.
I am not responsible for any future Vac or overwatch bans. Usage at your own risk! 
This project was created to study game hacking with python.

# Features

- Aimlock
- Walls
- Bunny hop
- No flash
- Skin changer (weapons only)

# Setup

- Download the zip from this repository
- Extract the zip
- Install Python 3.8 (https://www.python.org/downloads/) and check the box Add Python 3.8 to PATH
- open the windows command prompt
- navigate the windows command prompt to the path of the cheat folder typing cd "folder path"
- run installer: type python installer.py and follow instructions 
- run cheat: type python csgo.py
- run csgo
- Have fun!

For further help have a look at the instructions.txt

# Credits

- https://github.com/XanOpiat for the installer and skin changer
- Guided hacking (https://guidedhacking.com/)
- Unknown Cheats
